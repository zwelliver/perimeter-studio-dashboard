#!/bin/bash
# Run the Forecast to Official Request Matcher
cd ~/Scripts/StudioProcesses
source myenv/bin/activate
python3 forecast_to_official_matcher.py
